// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MptutGameMode.generated.h"

UCLASS(minimalapi)
class AMptutGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AMptutGameMode();
};



